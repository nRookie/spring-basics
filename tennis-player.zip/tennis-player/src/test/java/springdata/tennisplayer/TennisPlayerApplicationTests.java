package springdata.tennisplayer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TennisPlayerApplicationTests {

	@Test
	void contextLoads() {
	}

}
