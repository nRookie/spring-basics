package com.qing.jpa.jpaplayer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaPlayerApplicationTests {

	@Test
	void contextLoads() {
	}

}
