package com.qing.jpa.jpaplayer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaPlayerApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaPlayerApplication.class, args);
	}

}
